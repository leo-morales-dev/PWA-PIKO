import flet as ft
import requests

API_URL = "http://127.0.0.1:9000/api"  # tu backend

def main(page: ft.Page):
    page.title = "Cafetería Universitaria"
    page.scroll = "auto"
    page.theme_mode = ft.ThemeMode.LIGHT

    # Mensaje de carga
    status_text = ft.Text("Cargando menú...", size=20)
    page.add(status_text)
    page.update()

    # Intentar obtener el menú
    try:
        menu = requests.get(f"{API_URL}/menu").json()
    except Exception as e:
        status_text.value = f"No se pudo cargar el menú 😢\nError: {e}"
        page.update()
        return

    status_text.value = "Selecciona tus productos ☕"
    page.update()

    # Carrito
    carrito = []

    def agregar_producto(e, producto):
        carrito.append(producto)
        total = sum(p["precio"] for p in carrito)
        total_text.value = f"Total: ${total}"
        page.update()

    productos_column = ft.Column(spacing=10)
    for p in menu:
        card = ft.Container(
            content=ft.Column([
                ft.Text(p["nombre"], weight="bold"),
                ft.Text(f"${p['precio']}"),
                ft.ElevatedButton("Agregar", on_click=lambda e, p=p: agregar_producto(e, p))
            ]),
            padding=10,
            border=ft.border.all(1, "#ccc"),
            border_radius=10
        )
        productos_column.controls.append(card)

    total_text = ft.Text("Total: $0", size=18, weight="bold")

    def enviar_pedido(e):
        if not carrito:
            page.snack_bar = ft.SnackBar(ft.Text("No hay productos en el carrito"))
            page.snack_bar.open = True
            page.update()
            return
        pedido = {
            "id": len(carrito),  # simple demo
            "productos": [p["id"] for p in carrito],
            "total": sum(p["precio"] for p in carrito),
            "estado": "pendiente"
        }
        try:
            r = requests.post(f"{API_URL}/pedidos", json=pedido)
            if r.status_code == 200:
                page.snack_bar = ft.SnackBar(ft.Text("✅ Pedido enviado correctamente"))
                carrito.clear()
                total_text.value = "Total: $0"
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f"Error: {r.status_code}"))
            page.snack_bar.open = True
            page.update()
        except Exception:
            page.snack_bar = ft.SnackBar(ft.Text("📡 Sin conexión, pedido no enviado"))
            page.snack_bar.open = True
            page.update()

    page.add(
        ft.Column(
            [
                ft.Text("Menú", size=24, weight="bold"),
                productos_column,
                total_text,
                ft.ElevatedButton("Enviar Pedido", on_click=enviar_pedido),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )

ft.app(target=main, view=ft.AppView.WEB_BROWSER)
